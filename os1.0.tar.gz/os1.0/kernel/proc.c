
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                               proc.c
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                                                    Forrest Yu, 2005
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

#include "type.h"
#include "const.h"
#include "protect.h"
#include "proto.h"
#include "string.h"
#include "proc.h"
#include "global.h"
/*======================================================================*
                              multi-level feedback queue
*=========================================================================*/


/***init queue**/
void InitQueue() /*创建就绪队列*/  
{  
   ReadyQueue tmp;  
   int tmp_round = 5; //time flips: 5, 10, 15 
   int i;  
   for(i = 0;i < NR_Queues; i++)  
   {    
       tmp.front = 0;
       tmp.rear = 0;
       tmp.maxsize = LEN_Queue;
       tmp.round = tmp_round;
       tmp.prio = 50 - tmp.round;  /*设置其优先级，时间片越高，其优先级越低*/
       int j;
                
       Queue[i] = tmp;     /*按照优先级从高到低，建立多个就绪队列*/  
       tmp_round += 5;
   }  
} 
//判断循环链表是否满
int FullQueue(ReadyQueue *Q)  
{  
    if(Q->front==(Q->rear+1)%Q->maxsize)  
        return 1;  
    else  
        return 0;  
} 
//判断是否为空 
int EmptyQueue(ReadyQueue *Q)  
{  
    if(Q->front==Q->rear)      
        return 1;  
    else  
        return 0;  
}  

/**********Get the first process in a Queue**************/
void GetFirst(ReadyQueue *Q)     /*取得某一个就绪队列中的队头进程*/  
{  
    if(EmptyQueue(Q))  
    {  
        disp_str("NO Process!");   

       while(1){} 
    }  
    else  
    {    
        p_proc_ready = &Q ->Pro_Queue[Q->front];    
    }  
}  
/*remove the first node*/
void PopQueue(ReadyQueue *Q) 
{ 
    if(EmptyQueue(Q))  
    {  
        disp_str("Queue has been empty!");  
    }  
    else  
    {    
        Q->front=(Q->front+1) % Q->maxsize;    
    }  
} 
 /*将进程插入到就绪队列尾部*/
void InsertLast(PROCESS p,ReadyQueue *Q)   
{
    if(FullQueue(Q))  
        disp_str("Queue has been full!");  
    else  
    {   
       Q->Pro_Queue[Q->rear] = p;  
       Q->rear=(Q->rear+1) % Q->maxsize;   
    }    
} 
 
/*******Last Queue*****************************/
void RoundRun(ReadyQueue *queue)    /*时间片轮转调度算法*/  
{    
    int flag = 1;      
    if(!EmptyQueue(queue))  
    {  
        //while(flag)  
        //{ 
disp_str("~round~");
            p_proc_ready->count++;    
            p_proc_ready->time--;  
            if(p_proc_ready->time == 0) /*进程执行完毕*/  
            {   
                PopQueue(queue);
                flag = 0;  
            }  
            else if(p_proc_ready->count == queue ->round)/*时间片用完*/  
            {  
                PopQueue(queue); 
                p_proc_ready->count = 0;   /*计数器清零，为下次做准备*/  
                InsertLast(*p_proc_ready,queue);  
                flag = 0;  
            }  
        //}  
        if(flag == 1)
        { 
             return;
        }  
        GetFirst(queue);  
    }  
}  
void initPro_ready()
{
    ReadyQueue *queue;  
    queue = &Queue[Q_index];    //First queue, Prio max
    while(EmptyQueue(queue))/*就绪队列指针下移*/ 
    { 
        //disp_str(".empty.");
        //disp_int(index);
        if(Q_index == NR_Queues - 1 )  
        {  //disp_str(".last.");
            //disp_int(index);     
            break;   
        }  
        Q_index++;
        queue = &Queue[Q_index];        
    }      
    GetFirst(queue);
}
void MultiLevel()   /*多级调度算法，每次执行一个时间片*/  
{  
    int flag = 1;
    int index = Q_index;
    ReadyQueue *queue;  
    queue = &Queue[Q_index];    //First queue, Prio max
    if(!EmptyQueue(queue))  
    {   
        if(Q_index == NR_Queues - 1 )  
        {  
            RoundRun(queue);  
            return;  
        }        
        //while(flag)  
       // {  
            p_proc_ready->count++;   
            p_proc_ready->time--;  
            if(p_proc_ready->time == 0) //进程执行完毕 
            {  
                PopQueue(queue);  
                disp_str("this process end!");
                flag = 0;  
            }  
            else if(p_proc_ready->count == queue ->round)//时间片用完  
            {  
                PopQueue(queue);
                p_proc_ready->count = 0;   //计数器清零，为下次做准备  
                InsertLast(*p_proc_ready,&Queue[index+1]);
                disp_str("Time up, jump to next queue!");
                flag = 0;   
                
            } 
        if(flag == 1)//time is not up
        {
            return;
        }      
        //}  
        //flag = 1;  
        if(EmptyQueue(queue))//就绪队列指针下移 
        { 
            Q_index++;
            queue = &Queue[Q_index]; 
        } 
       
        GetFirst(queue);  
    }  
}  
/*======================================================================*
                              schedule
 *======================================================================*/
PUBLIC void schedule()
{
	PROCESS* p;
	int	 greatest_ticks = 0;

	while (!greatest_ticks) {
		for (p = proc_table; p < proc_table+NR_TASKS; p++) {
			if (p->ticks > greatest_ticks) {
				greatest_ticks = p->ticks;
				p_proc_ready = p;
                                //disp_str("multilevel begin..");
                                //MultiLevel();
			}
		}

		/*if (!greatest_ticks) {
			for (p = proc_table; p < proc_table+NR_TASKS; p++) {
				p->ticks = p->priority;
			}
		}*/
	}
}

/*======================================================================*
                           sys_get_ticks
 *======================================================================*/
PUBLIC int sys_get_ticks()
{
	return ticks;
}

